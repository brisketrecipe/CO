import React from 'react';
import styles from './styles.module.css';
import FAQDropdown from '../../components/faq';

const FAQPage = () => {
    return (
        <div className={styles.container} id='faq'>
            <div className={styles.questionsWrapper}>
                <h1 className={styles.title}>FAQ</h1>
                <FAQDropdown />
            </div>
            <div className={styles.coverWrapper}>
                <img src='images/faq-cover.png' alt='FAQ Hero Image' className={styles.coverImg} />
            </div>
        </div>
    )
}

export default FAQPage;
