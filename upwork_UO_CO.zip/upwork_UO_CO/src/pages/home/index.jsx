import React from 'react';
import styles from './styles.module.css';

const HomePage = () => {
    return (
        <div className={styles.container} id='home'>
            <img src='images/team_cover.png' alt='Home Hero Image' className={styles.heroImg}
                onClick={() => {
                    const element = document.getElementById('roadmap');
                    if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                    }
                }} />
        </div>
    )
}

export default HomePage;
