import React from 'react';
import styles from './styles.module.css';

const RoadmapPage = () => {
    return (
        <div className={styles.container} id='roadmap'>
            <h1 className={styles.title}>Roadmap</h1>
            <img height={"100%"} src='images/roadmap_cover_v2.png' alt='Roadmap Cover Image' className={styles.coverImg} />
        </div>
    )
}

export default RoadmapPage; 
