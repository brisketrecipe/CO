import React from 'react';
import styles from './styles.module.css';

const TeamPage = () => {
    return (
        <div className={styles.container} id='team'>
            <div className={styles.profileContainer}>
                <h1 className={styles.profileTitle}>Team</h1>
                <div className={styles.profileRow}>
                    <img src='images/profile (1).png' alt='Profile Avatar' />
                    <img src='images/profile (2).png' alt='Profile Avatar' />
                    <img src='images/profile (3).png' alt='Profile Avatar' />
                    <img src='images/profile (4).png' alt='Profile Avatar' />
                    <img src='images/profile (5).png' alt='Profile Avatar' />
                    <img src='images/profile (6).png' alt='Profile Avatar' />
                </div>
            </div>
            <img src='images/team_cover.png' alt='Team Cover Image' className={styles.teamCover} />
        </div>
    )
}

export default TeamPage;
