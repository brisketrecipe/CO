import React from 'react';
import styles from './styles.module.css';

const StoryPage = () => {
    return (
        <div className={styles.container} id='story'>
            <div className={styles.infoWrapper}>
                <h1 className={styles.title}>Story</h1>
                <p className={styles.description}>
                    Club Ollie stands as an avant-garde skateboard brand within the Ethereum blockchain domain. Our visionary pursuit entails the elevation of subterranean cultural ethos, coupled with the profound dissemination of sporting virtues inherent to skateboarding, all orchestrated through the revolutionary lens of Web3. Our pioneering endeavour involves an amalgamation of the skateboard lifestyle with corporeal actuality, exemplified by the establishment of our inaugural Web3 skateboard brand supported by an innovative cryptocurrency payment framework. Amidst the pantheon of sports, skateboarding, though remarkably superlative, often remains overshadowed. In this juncture, Club Ollie emerges as a beacon of enlightenment, ushering in heightened awareness and due recognition for this exceptional athletic pursuit. With unwavering commitment, we invite you to traverse the threshold into the realm of skateboarding's hitherto unexplored dimensions through the prism of Club Ollie.
                </p>
            </div>
            <div className={styles.coverWrapper}>
            <img src='images/story-cover.png' alt='Story Cover Image' className={styles.coverImg} />
            </div>
        </div>
    )
}

export default StoryPage; 
