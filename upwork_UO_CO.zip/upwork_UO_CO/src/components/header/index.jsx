import React from 'react';
import styles from './styles.module.css';

const HeaderComponent = () => {
    const [sections] = React.useState(['home', 'story', 'roadmap', 'team', 'faq']);
    const [activeSection, setActiveSection] = React.useState('home');
    const scrollTo = (sectionName) => {
        setActiveSection(sectionName);
        const element = document.getElementById(sectionName);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    }
    return (
        <div className={styles.headerContainer}>
            <img src='images/logo.png' alt='Logo' />
            <ul className={styles.navigationRow}>

                {sections.map(section => {
                    return (
                        <li key={section}>
                            <a className={`${styles.navigationButton} ${activeSection === section ? "navigationActive" : ""}`} onClick={() => scrollTo(section)} id={`nav-${section}`}>{section.toUpperCase()}</a>
                        </li>
                    );
                })}
                <li>
                    <a className={styles.socialIconBtn} href='#'>
                        <img src='images/twitter.svg' alt='Twitter Icon' />
                    </a>
                </li>
                <li>
                    <a className={styles.socialIconBtn} href='#'>
                        <img src='images/discord.svg' alt='Discord Icon' />
                    </a>
                </li>
            </ul>
        </div>
    )
}

export default HeaderComponent;
