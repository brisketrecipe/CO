import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form } from 'react-bootstrap';

const faqOptions = [
  { value: 'soon', label: 'When is this coming?' },
  { value: 'easy peasy', label: 'How does it work?' },
];

function FAQDropdown() {
  const [selectedFAQ, setSelectedFAQ] = useState("");

  const handleSelectFAQ = (event) => {
    setSelectedFAQ(faqOptions.find((faq) => faq.label === event.target.value) || "");
  };

  return (
    <div className="mt-4">
      <Form.Select onChange={handleSelectFAQ} value={selectedFAQ}>
        <option value={""} disabled>Select FAQ</option>
        {faqOptions.map((option) => (
          <option key={option.label} value={option.label}>
            {option.label}
          </option>
        ))}
      </Form.Select>

      {selectedFAQ?.value && (
        <div className='mt-3'>
          <h2>Answer:</h2>
          <p>{selectedFAQ.value}</p>
          {/* Add more FAQ answers as needed */}
        </div>
      )}
    </div>
  );
}

export default FAQDropdown;
