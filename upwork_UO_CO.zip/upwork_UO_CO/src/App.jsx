import React from 'react';

import BaseLayout from './layout/baselayout';

import HomePage from './pages/home';
import TeamPage from './pages/team';
import RoadmapPage from './pages/roadmap';
import StoryPage from './pages/story';
import FAQPage from './pages/faq';

import './App.css';

function App() {
  return (
    <div className="App">
      <BaseLayout>
        <HomePage />
        <StoryPage />
        <RoadmapPage />
        <TeamPage />
        <FAQPage />
      </BaseLayout>
    </div>
  );
}

export default App;
