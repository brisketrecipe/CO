import React from 'react';

import HeaderComponent from '../components/header';

import styles from './baselayout.module.css';

const BaseLayout = ({ children }) => {
    return (
        <div className={styles.container}>
            <HeaderComponent />

            {children}
        </div>
    )
}

export default BaseLayout;
